import React from 'react';

function Contact() {
  return (
    <section className="contact" id="contact">
      <h1 className="heading">contact us</h1>

      <div className="row">
        <iframe
          className="map"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3902.553860393622!2d-77.06070788526978!3d-12.005341891494876!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9105cf4c80d83faf%3A0x3a96a45de0f26696!2sMAESTRO%20HOME%20CENTER!5e0!3m2!1ses!2spe!4v1644898782874!5m2!1ses!2spe"
          allowFullScreen
          loading="lazy"
        ></iframe>

        <form action="">
          <h3>get in touch</h3>
          <input type="text" placeholder="Name" className="box" required />
          <input type="email" placeholder="Email" className="box" required />
          <input type="tel" placeholder="Phone" className="box" required />
          <textarea placeholder="Message" className="box" cols="30" rows="10" required></textarea>
          <input type="submit" value="send message" className="btn" />
        </form>
      </div>
    </section>
  );
}

export default Contact;
