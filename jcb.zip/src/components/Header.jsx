import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faBars,
  faInfoCircle,
  faSearch,
  faUser,
  faTimes,
  faPhone,
  faEnvelope,
  faMapMarkerAlt,
} from '@fortawesome/free-solid-svg-icons';
import { faFacebookF, faTwitter, faInstagram, faLinkedin } from '@fortawesome/free-brands-svg-icons';

function Header() {
  const [isSearchActive, setSearchActive] = useState(false);
  const [isLoginActive, setLoginActive] = useState(false);
  const [isContactInfoActive, setContactInfoActive] = useState(false);

  const toggleSearch = () => {
    setSearchActive(!isSearchActive);
    setLoginActive(false); // Close login form if open
  };

  const toggleLogin = () => {
    setLoginActive(!isLoginActive);
    setSearchActive(false); // Close search form if open
  };

  const toggleContactInfo = () => {
    setContactInfoActive(!isContactInfoActive);
  };

  return (
    <>
      <header className="header">
        <a href="#" className="logo">
          We<span>Build</span>
        </a>

        <nav className="navbar">
          <a href="#home">home</a>
          <a href="#about">about</a>
          <a href="#services">services</a>
          <a href="#projects">projects</a>
          <a href="#pricing">pricing</a>
          <a href="#contact">contact</a>
          <a href="#blogs">blogs</a>
        </nav>

        <div className="icons">
          <FontAwesomeIcon icon={faBars} id="menu-btn" className="icon" />
          <FontAwesomeIcon icon={faInfoCircle} id="info-btn" className="icon" onClick={toggleContactInfo} />
          <FontAwesomeIcon icon={faSearch} id="search-btn" className="icon" onClick={toggleSearch} />
          <FontAwesomeIcon icon={faUser} id="login-btn" className="icon" onClick={toggleLogin} />
        </div>

        <form action="" className={`search-form ${isSearchActive ? 'active' : ''}`}>
          <input type="search" placeholder="Search here..." id="search-box" />
          <label htmlFor="search-box" className="icon">
            <FontAwesomeIcon icon={faSearch} />
          </label>
        </form>

        <form action="" className={`login-form ${isLoginActive ? 'active' : ''}`}>
          <h3>login form</h3>
          <input type="email" placeholder="Enter your email" className="box" />
          <input type="password" placeholder="Enter your password" className="box" />
          <div className="flex">
            <input type="checkbox" id="remember-me" />
            <label htmlFor="remember-me">remember me</label>
            <a href="#">forgot password?</a>
          </div>
          <input type="submit" value="login now" className="btn" />
          <p>
            don't have an account <a href="#">create one!</a>
          </p>
        </form>
      </header>

      <div className={`contact-info ${isContactInfoActive ? 'active' : ''}`}>
        <div id="close-contact-info" onClick={toggleContactInfo}>
          <FontAwesomeIcon icon={faTimes} className="icon" />
        </div>

        <div className="info">
          <FontAwesomeIcon icon={faPhone} className="icon" />
          <h3>phone number</h3>
          <p>+123-111-111-111</p>
          <p>+123-111-111-111</p>
        </div>

        <div className="info">
          <FontAwesomeIcon icon={faEnvelope} className="icon" />
          <h3>email address</h3>
          <p>user1@email.com</p>
          <p>user2@email.com</p>
        </div>

        <div className="info">
          <FontAwesomeIcon icon={faMapMarkerAlt} className="icon" />
          <h3>office address</h3>
          <p>Carretera Panamericana Sur Km 241</p>
        </div>

        <div className="share">
          <a href="#" className="icon"><FontAwesomeIcon icon={faFacebookF} /></a>
          <a href="#" className="icon"><FontAwesomeIcon icon={faTwitter} /></a>
          <a href="#" className="icon"><FontAwesomeIcon icon={faInstagram} /></a>
          <a href="#" className="icon"><FontAwesomeIcon icon={faLinkedin} /></a>
        </div>
      </div>
    </>
  );
}

export default Header;
